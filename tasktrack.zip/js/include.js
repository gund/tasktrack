const APP_DEBUG = false;

//document.write('<script type="text/javascript" src="js/jquery-1.10.2.min.js"></script>');
//document.write('<script type="text/javascript" src="js/jquery.indexeddb.min.js"></script>');
//document.write('<script type="text/javascript" src="js/utils.min.js"></script>');
//document.write('<script type="text/javascript" src="modules/modules.js"></script>');
//document.write('<script type="text/javascript" src="js/main.min.js"></script>');

document.write('<script type="text/javascript" src="js/prod/compiled_utils.js"></script>');
document.write('<script type="text/javascript" src="js/prod/compiled_windowtt.js"></script>');
document.write('<script type="text/javascript" src="js/prod/compiled_mcrypt.js"></script>');
document.write('<script type="text/javascript" src="js/prod/compiled_core.js"></script>');
document.write('<script type="text/javascript" src="js/prod/compiled_main.js"></script>');
document.write('<script type="text/javascript" src="modules/modules.js"></script>');