const APP_DEBUG = true;

document.write('<script type="text/javascript" src="js/jquery-1.10.2.js"></script>');
document.write('<script type="text/javascript" src="js/jquery.indexeddb.js"></script>');
document.write('<script type="text/javascript" src="js/utils.js"></script>');
document.write('<script type="text/javascript" src="modules/modules.js"></script>');
document.write('<script type="text/javascript" src="js/main.js"></script>');