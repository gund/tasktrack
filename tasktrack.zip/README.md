TaskTrack
=========

Track your spent time to your Projects and Tasks.

####Author: Alex Malkevich, https://www.facebook.com/gund07, https://vk.com/gund_ua
#####Actual Release: 1.0 First Production Build.
######If you find a bug, please report here: https://github.com/gund/tasktrack/issues

Lisenced under Apache License Version 2.0. Anyone can use, modify and redistribute this app whithout any warranty in non coomerce way.

You can create Projects and Tasks for time managment.
You can sync your app data and then open this app on
other device. This app doesn't need Internet connection.
The data will be stored on your PC and while you want
sync your data just enable Internet connection.

You can use TaskTrack here: http://ttrack.tk
