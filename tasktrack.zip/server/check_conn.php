<?php
$result = array("status" => "OK");

echo json_encode($result);