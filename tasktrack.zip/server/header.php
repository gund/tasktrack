<?php
require_once 'misc.php';
require_once 'DataBase.php';
require_once 'class.MC.php';
require_once 'User.php';
